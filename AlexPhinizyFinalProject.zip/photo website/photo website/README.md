This is a website that uses the Flickr API to generate a mosaic based on what the user searches.
